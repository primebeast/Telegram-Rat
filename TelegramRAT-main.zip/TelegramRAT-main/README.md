# TelegramRAT
    Cross Platform Telegram based RAT that communicates via telegram to evade network restrictions
![tel](https://github.com/machine1337/TelegramRAT/assets/82051128/bb2d8fc0-ed6e-421a-a8be-3f049620138e)

# Note:
    Use New Cross Platform RAT https://github.com/machine1337/pyFUD
    
# Installation:
    1. git clone https://github.com/machine1337/TelegramRAT.git
    2. Now Follow the instructions in HOW TO USE Section.
    
# DEMO:
https://github.com/machine1337/TelegramRAT/assets/82051128/e7d92865-c6be-4b88-8453-634a8475cc14

# HOW TO USE:
    1. Go to Telegram and search for https://t.me/BotFather
    2. Create Bot and get the API_TOKEN
    3. Now search for https://t.me/chatIDrobot and get the chat_id
    4. Now Go to client.py and go to line 16 and 17 and place API_TOKEN and chat_id there
    5. Now run python client.py For Windows and python3 client.py For Linux
    6. Now Go to the bot which u created and send command in message field
  ![bo](https://github.com/machine1337/TelegramRAT/assets/82051128/575f8021-37f7-4ee8-886f-f3fd0acc2d3f)

# HELP MENU:
    HELP MENU: Coded By Machine1337
    CMD Commands        | Execute cmd commands directly in bot
    cd ..               | Change the current directory
    cd foldername       | Change to current folder
    download filename   | Download File From Target
    screenshot          | Capture Screenshot
    info                | Get System Info
    location            | Get Target Location
    get url             | Download File From URL (Provide Direct URL)
    
# Features:
    1. Execute Shell Commands in bot directly.
    2. download file from client.
    3. Get Client System Information.
    4. Get Client Location Information.
    5. Capture Screenshot
    6. get url (Download file from URL)
    7. More features will be added

# Author:
    Coded By: Machine1337
    Telgram group: https://t.me/machine1337
    
